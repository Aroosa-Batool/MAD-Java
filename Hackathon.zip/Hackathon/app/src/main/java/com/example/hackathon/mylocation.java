package com.example.hackathon;


    public class mylocation {
        public double lat;
        public double lng;

        public mylocation(double Lat, double Lng){
            lat = Lat;
            lng = Lng;
        }
    }

